#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<limits.h>

// CodeCamp.c -- EE 312 Project 1

/* Student information for project:
 *
 * Replace <NAME> with your name.
 *
 * On my honor, Tejal Kulkarni, this programming project is my own work
 * and I have not provided this code to any other student.
 *
 * Name: Tejal Kulkarni
 * email address: tejalkulkarni@utexas.edu
 * UTEID: tk8563
 * Section 5 digit ID:16025
 *
 */



/* Determine the hamming distance between two int arrays.
   pre: aList != null, bList != null, aList.length == bList.length == len
   post: return hamming distance between the two arrays of ints.
   Neither parameter should be altered by this function.
*/

int hammingDistance(int aList[], int bList[], int len) {
    int dist=0;                                                  //dist contains the hamming distance
    for(int count= 0; count!=len;  count++){
        if (aList[count] != bList[count]) {                     //compare each element of aList with bList
            dist++;
        }
    }
    return(dist);
}


/* Determine if two ints have the same last digit.
   Note that the last digit of 0 is 0 and the last digit of -12 is 2.
   post: return true if num1 and num2 have the same last digit, false otherwise.
*/

bool lastDigit(int num1, int num2) {

   if(abs(num1 % 10)==abs(num2 % 10)){                          //comparing the last digit but finding mod 10 of the parameter
       return true;
   }
   else{
       return false;
   }

}

/* Determine the sum of the positive integers less than 1000 that are multiples of 3 or 5 (or both).
   post: return the sum of the integers from 1 to 1000 that are multiples of 3 or 5 or both.
*/

int sum3or5Multiples() {
    int num; int sum=0;
        for(num=1;num<1000;num++) {
            if (num % 3 == 0 || num % 5 == 0) {                 //check remainder of mod 3 and 5 is zero to show it is a multiple
                sum = sum + num;                                //recursively add until 1000 is hit
            }

        }
    return(sum);
}

/* Reverse the digits of an integer. Return the reversed number if it is in the range of type int, 0 otherwise.
   post: return num with digits reversed if the reverse can be stored as an int, 0 otherwise.
*/

int reverseInt(int num) {
    int reverse=0;
        if(num<2,147,483,647 && num>-2,147,483,647) {
            while (abs(num) > 0) {
                reverse = (reverse * 10) + (num % 10);             //shift each digit, starting at ones, by tens place each loop
                num /= 10;
            }
        }
         else {
            return 0;
        }
    if(reverse<2,147,483,647 && reverse>-2,147,483,647) {           //check reverse number for overflow
        return (reverse);
    }
    else{
        return 0;
    }
}

